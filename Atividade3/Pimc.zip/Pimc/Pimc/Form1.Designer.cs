﻿namespace Pimc
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblPeso = new Label();
            lblAltura = new Label();
            mskboxPeso = new MaskedTextBox();
            mskboxAltura = new MaskedTextBox();
            txtImc = new TextBox();
            lblImc = new Label();
            btnCalcular = new Button();
            btnLimpar = new Button();
            btnSair = new Button();
            SuspendLayout();
            // 
            // lblPeso
            // 
            lblPeso.AutoSize = true;
            lblPeso.Location = new Point(203, 54);
            lblPeso.Name = "lblPeso";
            lblPeso.Size = new Size(32, 15);
            lblPeso.TabIndex = 0;
            lblPeso.Text = "Peso";
            // 
            // lblAltura
            // 
            lblAltura.AutoSize = true;
            lblAltura.Location = new Point(203, 125);
            lblAltura.Name = "lblAltura";
            lblAltura.Size = new Size(39, 15);
            lblAltura.TabIndex = 1;
            lblAltura.Text = "Altura";
            // 
            // mskboxPeso
            // 
            mskboxPeso.Location = new Point(321, 51);
            mskboxPeso.Mask = "000.00";
            mskboxPeso.Name = "mskboxPeso";
            mskboxPeso.Size = new Size(147, 23);
            mskboxPeso.TabIndex = 2;
            mskboxPeso.Validated += mskboxPeso_Validated;
            // 
            // mskboxAltura
            // 
            mskboxAltura.Location = new Point(321, 122);
            mskboxAltura.Mask = "0.00";
            mskboxAltura.Name = "mskboxAltura";
            mskboxAltura.Size = new Size(147, 23);
            mskboxAltura.TabIndex = 3;
            mskboxAltura.Validated += mskboxAltura_Validated;
            // 
            // txtImc
            // 
            txtImc.Location = new Point(321, 202);
            txtImc.Name = "txtImc";
            txtImc.Size = new Size(147, 23);
            txtImc.TabIndex = 4;
            // 
            // lblImc
            // 
            lblImc.AutoSize = true;
            lblImc.Location = new Point(203, 205);
            lblImc.Name = "lblImc";
            lblImc.Size = new Size(29, 15);
            lblImc.TabIndex = 5;
            lblImc.Text = "IMC";
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(166, 270);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(75, 23);
            btnCalcular.TabIndex = 6;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(288, 270);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(75, 23);
            btnLimpar.TabIndex = 7;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(407, 270);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(75, 23);
            btnSair.TabIndex = 8;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(687, 388);
            Controls.Add(btnSair);
            Controls.Add(btnLimpar);
            Controls.Add(btnCalcular);
            Controls.Add(lblImc);
            Controls.Add(txtImc);
            Controls.Add(mskboxAltura);
            Controls.Add(mskboxPeso);
            Controls.Add(lblAltura);
            Controls.Add(lblPeso);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblPeso;
        private Label lblAltura;
        private MaskedTextBox mskboxPeso;
        private MaskedTextBox mskboxAltura;
        private TextBox txtImc;
        private Label lblImc;
        private Button btnCalcular;
        private Button btnLimpar;
        private Button btnSair;
    }
}
