namespace Pimc
{
    public partial class Form1 : Form
    {

        double altura;
        double peso;
        double imc;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskboxPeso.Clear();
            mskboxAltura.Clear();
            txtImc.Clear();
        }

        private void mskboxPeso_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskboxPeso.Text, out peso) || peso <= 0)
            {
                MessageBox.Show("Peso Inv�lido");
                mskboxPeso.Focus();// como o evento validated j� saiu da caixa de texto precisa usar o focus para voltar nela. quando usamos o validanting precisa colocar o e.cancel
            }


        }

        private void mskboxAltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskboxAltura.Text, out altura) || altura <= 0)
                MessageBox.Show("Altura inv�lida");
            mskboxAltura.Focus();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            imc = peso / Math.Pow(altura, 2);
            txtImc.Text = imc.ToString("N1");
            imc = Math.Round(imc, 1);
            if(imc < 18.5)
                MessageBox.Show("Classifica��o: Magreza");
            else if (imc < 24.9)
                MessageBox.Show("Classifica��o: Normal");
            else if (imc < 29.9)
                MessageBox.Show("Classifica��o: Sobrepeso");
            else if (imc < 39.9)
                MessageBox.Show("Classifica��o: Obesidade");
            else
                MessageBox.Show("Classifica��o: Obesidade grave");
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
