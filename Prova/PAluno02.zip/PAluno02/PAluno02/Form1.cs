﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAluno02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[2, 3];
            string auxiliar;
            double somas = 0;
            string saida1 = "";
            string saida2 = "";
            string saidaMedia = "";
            string divisao = "--------------------------------------";

            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox("Digite as notar", "Entrada de dados");

                    if (!Double.TryParse(auxiliar, out notas[i, j]))
                    {
                        MessageBox.Show("Valor inválido");
                        j--;
                    }
                    if (notas[i, j] < 0 || notas[i, j] > 10)
                    {
                        MessageBox.Show("As notas precisam estar entre 0 e 10");
                        j--;
                    }
                }
            }

            for(int i = 0;i < 2;i++)
            {
                for(int j = 0; j < 3; j++)
                {
                    somas += notas[i, j];
                }
            }

            saidaMedia = $"\n Média geral dos alunos: {somas / 6}";

            saida1 = "\n Aluno 1 " + $"Nota professor 1: {notas[0, 0]} " + $"Nota professor 2: {notas[0, 1]} " + $"Nota professor 3: {notas[0, 2]}\n";

            saida2 = "\n Aluno 2 " + $"Nota professor 1: {notas[1, 0]} " + $"Nota professor 2: {notas[1, 1]} " + $"Nota professor 3: {notas[1, 2]}\n";

            lstbxSaida.Items.Add(saida1);
            lstbxSaida.Items.Add(saida2);
            lstbxSaida.Items.Add(divisao);
            lstbxSaida.Items.Add(saidaMedia);
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxSaida.Items.Clear();
        }
    }
}
