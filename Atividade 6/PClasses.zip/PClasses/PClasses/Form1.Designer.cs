﻿namespace PClasses
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnHorista = new Button();
            btnMensalista = new Button();
            SuspendLayout();
            // 
            // btnHorista
            // 
            btnHorista.Location = new Point(107, 183);
            btnHorista.Name = "btnHorista";
            btnHorista.Size = new Size(187, 100);
            btnHorista.TabIndex = 0;
            btnHorista.Text = "Horista";
            btnHorista.UseVisualStyleBackColor = true;
            btnHorista.Click += btnHorista_Click;
            // 
            // btnMensalista
            // 
            btnMensalista.Location = new Point(518, 183);
            btnMensalista.Name = "btnMensalista";
            btnMensalista.Size = new Size(187, 100);
            btnMensalista.TabIndex = 1;
            btnMensalista.Text = "Mensalista";
            btnMensalista.UseVisualStyleBackColor = true;
            btnMensalista.Click += btnMensalista_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnMensalista);
            Controls.Add(btnHorista);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Button btnHorista;
        private Button btnMensalista;
    }
}
