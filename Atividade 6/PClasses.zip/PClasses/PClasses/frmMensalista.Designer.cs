﻿namespace PClasses
{
    partial class frmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblMatricula = new Label();
            lblNome = new Label();
            lblSalario = new Label();
            lblData = new Label();
            txtMatricula = new TextBox();
            txtNome = new TextBox();
            txtSalario = new TextBox();
            txtData = new TextBox();
            btnInstanciar = new Button();
            btnParametros = new Button();
            SuspendLayout();
            // 
            // lblMatricula
            // 
            lblMatricula.AutoSize = true;
            lblMatricula.Location = new Point(103, 85);
            lblMatricula.Name = "lblMatricula";
            lblMatricula.Size = new Size(57, 15);
            lblMatricula.TabIndex = 0;
            lblMatricula.Text = "Matrícula";
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Location = new Point(103, 139);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(40, 15);
            lblNome.TabIndex = 1;
            lblNome.Text = "Nome";
            // 
            // lblSalario
            // 
            lblSalario.AutoSize = true;
            lblSalario.Location = new Point(103, 192);
            lblSalario.Name = "lblSalario";
            lblSalario.Size = new Size(83, 15);
            lblSalario.TabIndex = 2;
            lblSalario.Text = "Salário mensal";
            // 
            // lblData
            // 
            lblData.AutoSize = true;
            lblData.Location = new Point(103, 242);
            lblData.Name = "lblData";
            lblData.Size = new Size(154, 15);
            lblData.TabIndex = 3;
            lblData.Text = "Data de entrada na empresa";
            // 
            // txtMatricula
            // 
            txtMatricula.Location = new Point(294, 77);
            txtMatricula.Name = "txtMatricula";
            txtMatricula.Size = new Size(394, 23);
            txtMatricula.TabIndex = 4;
            // 
            // txtNome
            // 
            txtNome.Location = new Point(294, 131);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(394, 23);
            txtNome.TabIndex = 5;
            // 
            // txtSalario
            // 
            txtSalario.Location = new Point(294, 184);
            txtSalario.Name = "txtSalario";
            txtSalario.Size = new Size(394, 23);
            txtSalario.TabIndex = 6;
            // 
            // txtData
            // 
            txtData.Location = new Point(294, 234);
            txtData.Name = "txtData";
            txtData.Size = new Size(394, 23);
            txtData.TabIndex = 7;
            // 
            // btnInstanciar
            // 
            btnInstanciar.Location = new Point(294, 318);
            btnInstanciar.Name = "btnInstanciar";
            btnInstanciar.Size = new Size(187, 52);
            btnInstanciar.TabIndex = 8;
            btnInstanciar.Text = "Instanciar mensalista";
            btnInstanciar.UseVisualStyleBackColor = true;
            btnInstanciar.Click += btnInstanciar_Click;
            // 
            // btnParametros
            // 
            btnParametros.Location = new Point(501, 318);
            btnParametros.Name = "btnParametros";
            btnParametros.Size = new Size(187, 52);
            btnParametros.TabIndex = 9;
            btnParametros.Text = "Instanciar passando pelos parametros";
            btnParametros.UseVisualStyleBackColor = true;
            btnParametros.Click += btnParametros_Click;
            // 
            // frmMensalista
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnParametros);
            Controls.Add(btnInstanciar);
            Controls.Add(txtData);
            Controls.Add(txtSalario);
            Controls.Add(txtNome);
            Controls.Add(txtMatricula);
            Controls.Add(lblData);
            Controls.Add(lblSalario);
            Controls.Add(lblNome);
            Controls.Add(lblMatricula);
            Name = "frmMensalista";
            Text = "frmMensalista";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblMatricula;
        private Label lblNome;
        private Label lblSalario;
        private Label lblData;
        private TextBox txtMatricula;
        private TextBox txtNome;
        private TextBox txtSalario;
        private TextBox txtData;
        private Button btnInstanciar;
        private Button btnParametros;
    }
}