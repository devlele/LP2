namespace PVolume
{
    public partial class Form1 : Form
    {
        double raio;
        double altura;
        double volume;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtRaio.Text, out raio))
            {
                MessageBox.Show("Raio inv�lido!");
                txtRaio.Focus();
            }
            else
            {
                if (raio <= 0)
                {
                    MessageBox.Show("Raio deve ser maior que zero");
                    txtRaio.Focus();
                }
            }
        }



        private void txtAltura_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (!double.TryParse(txtAltura.Text, out altura))
            {
                MessageBox.Show("Altura invalida");
                e.Cancel = true;// n�o deixa passar para o proximo est�gio
            }
            else
            {
                if (altura <= 0)
                {
                    MessageBox.Show("A altura n�o pode ser menor que zero");
                    e.Cancel = true;
                }
            }

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            volume = Math.PI * Math.Pow(raio, 2) * altura;
            txtVolume.Text = volume.ToString("N2");//pega a variavel double e converte para string. O N2 mostra duas casas decimais 
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtRaio.Clear();
            txtVolume.Clear();//limpar dados
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
